#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "")package ${PACKAGE_NAME};#end
#parse("File Header.java")
/**
 * @author huaihai.guan
 * @date ${DATE} ${TIME}
 */
public interface ${NAME} {
}
